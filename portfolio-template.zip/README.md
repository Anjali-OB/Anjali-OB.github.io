# Portfolio template

A single-file, animated portfolio: grand entry animation, minimal first page, 3D tilt cards, neural-network background, 3D skills sphere, project filters with a hover Star button, certificate and review galleries, a chatbot (RAG), a separate Guestbook page, a Free-template page and a video section.

Created by Anjali Khadke (https://github.com/Anjali-OB). If you use it, a star on the portfolio repository is always appreciated.

## Quick start
1. Open `index.html` in a text editor and search for **Your**, **example** and **your-username**. Replace them with your details.
2. Edit the data blocks inside the `<script>`: `SK` (skills), `PJ` (projects), `EX` (experience), `CE` (certificates), the `#ed` education list, `KB` (chatbot facts), `QS` (rotating quotes), `GH` (GitHub repo for each project's Star button) and `CAT` (project filter categories).
3. Replace every "Your image here" picture. Images are embedded as base64. Convert each picture to base64 (for example at base64.guru) and paste it in place of a placeholder starting with `data:image/svg+xml`.
4. Add `Your_Resume.pdf` and `video.mp4` next to `index.html` (or remove those sections).
5. Upload everything to a GitHub repository named `your-username.github.io`, then turn on Settings > Pages.

## Optional extras
- The chatbot with LLM answers and the Guestbook need a free Cloudflare Worker (chatbot key as a secret, plus a KV namespace bound as `GUESTBOOK`). Put the Worker URL into `const WORKER=''`.
- Colours are CSS variables at the top (`--ac`, `--ac3`, `--ac2`).
